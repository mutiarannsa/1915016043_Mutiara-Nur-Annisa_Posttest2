import 'package:flutter/material.dart';

class landing_page extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    var tinggi = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Color(0xfffF6F3F3),
      body: ListView(children: [
        Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
          Container(
              width: lebar,
              height: tinggi,
              child: Stack(
                fit: StackFit.expand,
                alignment: Alignment.center,
                children: [
                  Positioned(
                    top: 0,
                    width: lebar,
                    height: 274,
                    child: Opacity(
                      opacity: 0.6,
                      child: Container(
                        child: Image.asset(
                          "icecream.png",
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 0,
                    top: 119,
                    width: lebar,
                    height: 0,
                    child: Align(
                      alignment: Alignment.center,
                      child: Text(
                        "Ice Cream",
                        overflow: TextOverflow.visible,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          height: 1.2,
                          fontSize: 30,
                          fontWeight: FontWeight.w900,
                          color: Color(0xfffA68078),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 0,
                    top: 160,
                    width: lebar,
                    height: 0,
                    child: Align(
                      alignment: Alignment.center,
                      child: Text(
                        "by mutiarannsa",
                        overflow: TextOverflow.visible,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          height: 1.2,
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                          color: Color(0xfffA68078),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 119,
                    top: 327,
                    width: lebar,
                    height: 74,
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "Your Ice Cream truck is here!",
                        overflow: TextOverflow.visible,
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          height: 3,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 150,
                    top: 486,
                    width: lebar,
                    height: 37,
                    child: Container(
                      width: 185,
                      height: 37,
                      child: Stack(
                          fit: StackFit.expand,
                          alignment: Alignment.center,
                          children: [
                            Positioned(
                              left: 0,
                              top: 0,
                              width: 185,
                              height: 37,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(45),
                                child: Container(
                                  color: Color(0xfffA68078),
                                ),
                              ),
                            ),
                            Positioned(
                              left: 57,
                              top: 11,
                              width: 74,
                              height: 17,
                              child: Align(
                                alignment: Alignment.center,
                                child: Text(
                                  "Get Started",
                                  overflow: TextOverflow.visible,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    height: 1.2,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            )
                          ]),
                    ),
                  ),
                ],
              )),
        ]),
      ]),
    );
  }
}
